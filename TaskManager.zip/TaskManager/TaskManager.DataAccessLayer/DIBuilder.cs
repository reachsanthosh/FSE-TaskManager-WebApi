﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace TaskManager.DataAccessLayer
{
   public static class DIBuilder
    {
        public static void Build(IServiceCollection services, IConfiguration config)
        {
            

        }
    }
}
